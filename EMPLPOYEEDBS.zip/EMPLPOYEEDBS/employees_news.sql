-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: employees
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` bigint DEFAULT NULL,
  `title` text,
  `content` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (5,'New Employee Benefits Program Launched','We are excited to announce the launch of our enhanced employee benefits program. The new program includes additional health coverage options, wellness initiatives, and increased flexibility. We believe these changes will contribute to the overall well-being of our team. Please check your email for detailed information.'),(1,'Office Expansion Update','Great news! Due to our company\'s continued growth, we are expanding our office space. The construction is progressing well, and we expect the new workspace to be ready by the end of next month. We appreciate your patience and cooperation during this exciting time for our organization.'),(2,'Employee Recognition Awards Ceremony','It\'s time to celebrate our outstanding team members! Join us for the Employee Recognition Awards Ceremony on [date]. We will be acknowledging individuals who have demonstrated exceptional dedication, innovation, and teamwork. Your hard work does not go unnoticed, and we look forward to honoring our exceptional colleagues'),(3,'Professional Development Opportunities','We are committed to supporting your professional growth. A series of workshops and training sessions covering various skills and competencies are scheduled for the upcoming months. Take advantage of these opportunities to enhance your knowledge and capabilities. Look out for further details in your inbox.'),(4,'Annual Employee Survey','Your feedback is invaluable to us! The annual employee survey is now open, and we encourage everyone to participate. This is your chance to share your thoughts, suggestions, and concerns anonymously. Your input will help us make informed decisions to improve the workplace for everyone. The survey link has been sent to your email.');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-15  3:02:54
